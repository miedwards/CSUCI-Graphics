#include <string>

using namespace std;


class RigidBody
{
public:
    //---- ctors
    RigidBody() : name("rigidbody") {}
    RigidBody( string nm ) : name(nm) {}
    
    //---- set/get
    void SetRotation( mat4 r ) { rotation = r;}
    mat4 GetRotation() { return rotation;}
    void SetTranslation( mat4 t ) {translation = t;}
    mat4 GetTranslation() {return translation;}
    void SetScale( mat4 s ) {scale = s;}
    mat4 GetScale() {return scale;}
    void SetVelocity( vec3 v ) {velocity = v;}
    vec3 GetVelocity() {return velocity;}
    vec3 GetPosition() {return vec3(translation[0][3], translation[1][3], translation[2][3]);}
    void SetPosition( vec3 p) { translation[0][3]=p.x; translation[1][3]=p.y; translation[2][3]=p.z;}
    void SetMass( float m ) {mass = m;}
    float GetMass() {return mass;}
    void SetBSradius( float r ) {bs_radius = r;}
    float GetBSradius() {return bs_radius;}
    string GetName() {return name;}
private:
    string name;
    float mass;
    mat4 translation, rotation, scale;
    vec3 velocity;
    float bs_radius;
};
