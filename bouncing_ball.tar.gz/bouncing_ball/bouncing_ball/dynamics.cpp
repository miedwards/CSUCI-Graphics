#include <iostream>
#include <string>
#include <vector>
#include <math.h>

#include "mat.h"
#include "RigidBody.h"

using namespace std;

extern vector<RigidBody> scene;


void DynamicSimEuler( vec3 F, float m, float dt, vec3* v, vec3* s );
void DynamicSimRK( float F, float m, float dt, float* v, float* s );

//----------------------------------------------------------------------------


bool
CollisionDetection( RigidBody& a, RigidBody& b, vec3* v )
{
    if ((b.GetScale())[1][1] > 1.0)  // walls
    {
        float diff1 = (b.GetTranslation())[0][3] - (a.GetTranslation())[0][3];
        if ( fabs( diff1 ) < a.GetBSradius() && (b.GetTranslation())[0][3] != 0.0)
        {
            cout << b.GetName() << " x " << (b.GetTranslation())[0][3] << ' ' << (a.GetTranslation())[0][3] << endl;
            if ( (diff1 < 0.0 && v->x < 0.0) || (diff1 > 0.0 && v->x > 0.0) )
                v->x = -v->x;
        }
    
        float diff2 = ((b.GetTranslation())[2][3]) - ((a.GetTranslation())[2][3]);
    
        if ( fabs(diff2)  < a.GetBSradius() && (b.GetTranslation())[2][3] != 0.0)
        {
            cout << b.GetName() << " z " << (b.GetTranslation())[2][3] << ' ' << (a.GetTranslation())[2][3] << endl;
            if ( (diff2 < 0.0 && v->z < 0.0) || (diff2 > 0.0 && v->z > 0.0) )
                v->z = -v->z;
        }
    }
    else  // ground
    {
        float diff3 = (b.GetTranslation())[1][3] - (a.GetTranslation())[1][3];
    
        if ( fabs(diff3)  < a.GetBSradius()/2.0 )
        {
            cout << b.GetName() << " y " << (b.GetTranslation())[1][3] << ' ' << (a.GetTranslation())[1][3] << endl;
            if ( (diff3 < 0.0 && v->y < 0.0) || (diff3 > 0.0 && v->y > 0.0) )
                v->y = -v->y;
        }
    }
    
    return false;
}



float t = 0.0;
bool collision = false;

void
Drop( RigidBody& rb, float dt )
{
    float k_units = 1.0;
    float g = 9.8;
    float k = 0.1;
    vec3 v = rb.GetVelocity();
    vec3 p = rb.GetPosition();
    float m = rb.GetMass();
    vec3 F = m*vec3(0.0, g, 0.0) + k*v;
    
    
    DynamicSimEuler( F, m, dt, &v, &p );
    //float vy = v.y;
    //float py = p.y;
    //DynamicSimRK( F.y, m, dt, &vy, &py );
    //v.y = vy;
    //p.y = py;
    
    t = t + dt;
    
    float sp_new = 10.0/k_units + ( -(m*m)/(k*k) * g * exp( -k*t/m) -  ((m*g)/k)*t  +  (m*m)/(k*k) * g );
                               
    
    //cout << dt << ' ' << vy << ' ' << sy << ' ' << sp_new << endl;
    cout << dt << ' ' << p.y << ' ' << sp_new << endl;
    
    for( int i = 0; i < scene.size(); i++ )
    {
        CollisionDetection(rb, scene[i], &v);
    }
    
    // squash
    if ( p.y < 2.0) rb.SetScale(Scale(fmax(3.0,3.0 + (1.0 - p.y)), fmax(p.y,2.0), fmax(3.0,3.0 + (1.0 - p.y))));

    
    rb.SetVelocity(vec3(v.x, v.y, v.z));
    rb.SetPosition(vec3(p.x, p.y, p.z));
}


//----------------------------------------------------------------------------


void
DynamicSimEuler( vec3 F, float m, float dt, vec3* v, vec3* s )
{
    vec3 a = F/m;
    *v = *v - a*dt;
    *s = *s + *v*dt;
}


//----------------------------------------------------------------------------


void
DynamicSimRK( float F, float m, float dt, float* v, float* s )
{
    float g = 9.8;
    float k = 0.1;
    float a;
    float k1, k2, k3, k4;
    
    F = m*g + k*(*v);
    a = F/m;
    k1 = a*dt;
    
    F = m*g + k*(*v + k1/2.0f);
    a = F/m;
    k2 = a*dt;
    
    F = m*g + k*(*v + k2/2.0f);
    a = F/m;
    k3 = a*dt;
    
    F = m*g + k*(*v + k3);
    a = F/m;
    k4 = a*dt;
    
    *v = *v - (k1 + 2*k2 +2*k3 + k4)/6.0f;
    *s = *s + *v*dt;
    
}



